package com.cg.eis.lab7.service;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.cg.eis.lab7.bean.Employee;

public class EmployeeServiceImpl implements iEmployeeService{
	
	
	
	Employee emp;
	HashMap<String,Employee> list = new HashMap<String,Employee>();
	@Override
	public void addEmployee(String name, Employee emp) {
		list.put(name, emp);
		
	}
	@Override
	public void deleteEmployee(String name) {
		list.remove(name);
		
	}
	@Override
	public String calcScheme(double Salary, String designation) {
		if((Salary>5000 && Salary<20000) && 
				(designation.equals("System Associate"))){
			return "Scheme C";
			
		}
		else
			if((Salary>=20000 && Salary<40000) && 
					(designation.equals("Programmer"))){
				return "Scheme B";
				
			}
			else
				if((Salary>=40000) && 
						(designation.equals("Manager"))){
					return "Scheme A";
				}
				else
					if((Salary<=5000) && 
							(designation.equals("Clerk"))){
						return "No Scheme";
					}
	return "Faulty Change";	
		
	}
	@Override
	public void sortAndDisplay() {
		Set tempset=list.entrySet();
		Iterator itr=tempset.iterator();
		while(itr.hasNext()){
			Map.Entry mapEntry=(Map.Entry)itr.next();
			System.out.println(mapEntry.getKey()+":"+mapEntry.getValue());
		}
		
	}

}
