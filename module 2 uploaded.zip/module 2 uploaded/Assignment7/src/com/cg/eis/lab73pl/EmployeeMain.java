package com.cg.eis.lab73pl;

import com.cg.eis.lab7.bean.Employee;
import com.cg.eis.lab7.service.EmployeeServiceImpl;
import com.cg.eis.lab7.service.iEmployeeService;

public class EmployeeMain {

	public static void main(String[] args) {
		Employee emp1= new Employee(101,"Aditya",15000,"System Associate");
		Employee emp2= new Employee(102,"Akshya",35000,"Programmer");
		Employee emp3= new Employee(103,"Raunak",5000,"Manager");
		Employee emp4= new Employee(104,"Prathamesh",50000,"Clerk");
		
		iEmployeeService es=new EmployeeServiceImpl();
		
		
		emp1.setInsuranceScheme(es.calcScheme(emp1.getSalary(), emp1.getDesignation()));
		emp2.setInsuranceScheme(es.calcScheme(emp2.getSalary(), emp2.getDesignation()));
		emp3.setInsuranceScheme(es.calcScheme(emp3.getSalary(), emp3.getDesignation()));
		emp4.setInsuranceScheme(es.calcScheme(emp4.getSalary(), emp4.getDesignation()));
		
		
		es.addEmployee("Prathamesh", emp1);
		es.addEmployee("Akshay", emp2);
		es.addEmployee("Aditya", emp3);
		es.addEmployee("Lobo", emp4);
		
		es.deleteEmployee("Lobo");
		es.sortAndDisplay();

	}

}
