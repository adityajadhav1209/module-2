import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;


public class PersonTest {
Person p;
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		p = new Person();
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testgetFirstName() {
		p= new Person("Aditya","jadhav",'M');
		assertEquals(p.getFirstName(),"Aditya");
	}

	@Test
	public void testgetLastName() {
		p= new Person("Aditya","jadhav",'M');
		assertEquals(p.getLastName(),"jadhav");
	}
	@Test
	public void testgetGender() {
		p= new Person("Aditya","jadhav",'M');
		assertEquals(p.getGender(),'M');
	}
}
