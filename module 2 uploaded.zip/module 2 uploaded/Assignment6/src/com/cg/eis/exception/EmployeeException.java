package com.cg.eis.exception;

public class EmployeeException extends Exception{
	
	private double sal;
	public EmployeeException(double salary){
		sal=salary;
	}
	@Override
	public String toString() {
		return "EmployeeException [Salary can't be less than 5000]"+"Salary entered is "+sal;
	}

}
