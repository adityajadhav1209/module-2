package com.cg.mobile.dto;

import java.util.Date;

public class Purchase {
	private String cname;
	private String mailid;
	private String phoneno;
	private int mobileid;
	private int quantity;

	public Purchase() {
		super();
	}

	public Purchase(String cname, String mailid,
			String phoneno,int mobileid,int quantity) {
		super();
		this.cname = cname;
		this.mailid = mailid;
		this.phoneno = phoneno;
		this.mobileid = mobileid;
		this.quantity=quantity;
	}
	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getMailid() {
		return mailid;
	}

	public void setMailid(String mailid) {
		this.mailid = mailid;
	}

	public String getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}

	public int getMobileid() {
		return mobileid;
	}

	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
}
