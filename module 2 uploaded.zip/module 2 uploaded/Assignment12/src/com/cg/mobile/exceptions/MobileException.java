package com.cg.mobile.exceptions;

public class MobileException extends Exception{
	public MobileException(String msg){
		super(msg);
	}

	
}
