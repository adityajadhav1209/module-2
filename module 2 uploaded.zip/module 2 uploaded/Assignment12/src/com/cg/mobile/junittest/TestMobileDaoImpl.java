package com.cg.mobile.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobile.dao.IMobileDao;
import com.cg.mobile.dao.MobileDaoImpl;
import com.cg.mobile.exceptions.MobileException;

public class TestMobileDaoImpl {
    IMobileDao iMobile;
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}
	@Before
	public void setup(){
		iMobile =new MobileDaoImpl();
	}

	@Test
	public void testShowAll() {
		try {
			assertNotNull(iMobile.showAll());
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testDeleteMobile(){
		try {
			assertTrue(iMobile.deleteMobile(1002));
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testSearchByRange(){
		try {
			assertNotNull(iMobile.searchByRange(100,40000));
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test
	public void testUpdateQty(){
		try {
			assertTrue(iMobile.updateQty(1003,2));
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@After
	public void tearDown(){
		
	}

}
