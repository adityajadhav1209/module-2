package com.cg.mobile.service;

import java.util.List;

import com.cg.mobile.dao.IMobileDao;
import com.cg.mobile.dao.MobileDaoImpl;
import com.cg.mobile.dto.Mobile;
import com.cg.mobile.exceptions.MobileException;

public class MobileServiceImpl implements IMobileService{
    IMobileDao imobile=new MobileDaoImpl();
 	public List<Mobile> showAllMobiles() throws MobileException {
		
		return imobile.showAll();
	}

	public boolean deleteMobile(int mobileid) throws MobileException {
		
		return imobile.deleteMobile(mobileid);
	}

	public List<Mobile> searchMobile(int start, int end) throws MobileException {
		
		return imobile.searchByRange(start, end);
	}

	public boolean update(int mobileid, int qty) throws MobileException {
		
		return imobile.updateQty(mobileid, qty);
	}

}
