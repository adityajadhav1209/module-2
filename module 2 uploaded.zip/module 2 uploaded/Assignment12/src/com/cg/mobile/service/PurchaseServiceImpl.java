package com.cg.mobile.service;

import com.cg.mobile.dao.IPurchaseDao;
import com.cg.mobile.dao.PurchaseDaoImpl;
import com.cg.mobile.dto.Purchase;
import com.cg.mobile.exceptions.MobileException;

public class PurchaseServiceImpl implements IPurchaseService{
 
	IPurchaseDao a=new PurchaseDaoImpl();
	public boolean InsertInto(Purchase p) throws MobileException {
	
		return a.Insert(p);
	}

}
