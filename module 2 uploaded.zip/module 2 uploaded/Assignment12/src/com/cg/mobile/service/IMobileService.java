package com.cg.mobile.service;

import java.util.List;

import com.cg.mobile.dto.Mobile;
import com.cg.mobile.exceptions.MobileException;

public interface IMobileService {
	List<Mobile> showAllMobiles() throws MobileException;
	boolean deleteMobile(int mobileid) throws MobileException;
	List<Mobile>searchMobile(int start,int end) throws MobileException;
	boolean update(int mobileid,int qty)throws MobileException;
}
