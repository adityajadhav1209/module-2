package com.cg.mobile.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mobile.dto.Mobile;
import com.cg.mobile.dto.Purchase;
import com.cg.mobile.exceptions.MobileException;
import com.cg.mobile.service.IMobileService;
import com.cg.mobile.service.IPurchaseService;
import com.cg.mobile.service.MobileServiceImpl;
import com.cg.mobile.service.PurchaseServiceImpl;
import com.cg.mobile.util.JdbcUtil;

public class MobileApplication {

	private static final Logger mylogger = Logger.getLogger(JdbcUtil.class);

	public static void main(String[] args) {
		IMobileService mobService = new MobileServiceImpl();
		IPurchaseService purService = new PurchaseServiceImpl();
		int choice = 0;
		PropertyConfigurator.configure("resources/log4j.properties");
		mylogger.info("Application started");
		do {
			printDetail();
			Scanner sc = new Scanner(System.in);
			System.out.println("Please Enter Choice:");
			choice = sc.nextInt();
			switch (choice) {
			case 1:// view
				List<Mobile> mList = new ArrayList<Mobile>();
				try {
					mList = mobService.showAllMobiles();
					for (Mobile show : mList) {
						System.out.println(show);
					}
				} catch (MobileException e) {

					e.printStackTrace();
				}
				break;
			case 2:// Delete
				System.out.println("Enter Mobile Id to Delete");
				int del = sc.nextInt();
				try {
					boolean val = mobService.deleteMobile(del);
					System.out.println(val);
				} catch (MobileException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 3: // Search
				List<Mobile> mList2 = new ArrayList<Mobile>();
				System.out.println("Enter Starting range value");
				int start = sc.nextInt();
				System.out.println("Enter Ending range value");
				int end = sc.nextInt();
				try {
					mList2 = mobService.searchMobile(start, end);
					for (Mobile show : mList2) {
						System.out.println(show);
					}
				} catch (MobileException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				break;
			case 4:// Insert
				Purchase p = new Purchase();
				//SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
				int count=0;
				//Taking Input
			
				System.out.println("Please Enter Customer Name");
				String name = sc.next();
				Pattern cname = Pattern.compile("^[A-Z]{1}[a-zA-Z]{0,19}$");
				Matcher name1 = cname.matcher(name);
				if(name1.matches()){
					p.setCname(name);
					count++;
				}
				
				
				System.out.println("Please Enter Email Id");
				String mail = sc.next();
				Pattern email = Pattern.compile("^[a-zA-Z0-9+_.-]+@[a-zA-Z]+.[a-z]+$");
				Matcher email1 = email.matcher(mail);
				if(email1.matches()){
					p.setMailid(mail);
					count++;
				}
				
				System.out.println("Please Enter Phone Number");
				String phone = sc.next();
				Pattern mobno = Pattern.compile("^[0-9]{10}$");
				Matcher mobno1 = mobno.matcher(phone);
				if(mobno1.matches())
				{
				p.setPhoneno(phone);
				count++;
				}
				
				System.out.println("Please Enter Mobile Id");
				int mobid = sc.nextInt();
				Pattern mobileId = Pattern.compile("^[0-9]{4}$");
				Matcher mobileId1 = mobileId.matcher(String.valueOf(mobid));
				if(mobileId1.matches())
				{
					p.setMobileid(mobid);
					count++;
				}
				System.out.println("Please Enter Quantity");
				int quant=sc.nextInt();
				if(quant>0)
				{
				p.setQuantity(quant);
				}
				else
				{
					System.out.println("Enter correct quantity");
				}
				if(count==4){
					boolean val;
					try {
						val = purService.InsertInto(p);
						System.out.println(val);
					} catch (MobileException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
				}
				else{
					System.out.println("Please Input purchase details again");
				}
				sc.close();
				
				break;

			case 5:// Exit
				break;

			}

		} while (choice != 5);

	}

	public static void printDetail() {
		System.out.println("**********");
		System.out.println("1. View Details Of All Mobiles");
		System.out.println("2. Delete Mobile Details");
		System.out.println("3. Search Mobile By Price Range");
		System.out.println("4. Purchase Mobile");
		System.out.println("5. Exit");
		System.out.println("***********");
	}
}
