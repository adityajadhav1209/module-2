package com.cg.mobile.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;
import com.cg.mobile.exceptions.MobileException;

public class JdbcUtil {
	private static final Logger mylogger=Logger.getLogger(JdbcUtil.class);
	
	public static Properties loadProperty(){
		FileInputStream file=null;
		
		Properties prop=new Properties();
		
		try {
			file=new FileInputStream("resources\\oracle.properties");
			prop.load(file);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	    return prop;

}
	public static Connection getConnection() throws MobileException{
		Connection con=null;
		Properties prop=loadProperty();
		String url=prop.getProperty("oracle.url");
		String driver=prop.getProperty("oracle.driver");
		String uname=prop.getProperty("oracle.uname");
		String upass=prop.getProperty("oracle.upass");
		try {
			
			Class.forName(driver);
			mylogger.info("Driver is loaded");
		}
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			mylogger.error("Driver is not loaded");
		}
			try {
				con=DriverManager.getConnection(url,uname,upass);
				mylogger.info("Connected to the database");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				mylogger.error("Not Connected");
				throw new MobileException("Connection Problem");
			}
	
	
		return con;
	}
/*	public static void main(String args[])
	{
		
		JdbcUtil j = new JdbcUtil();
		PropertyConfigurator.configure("resources/log4j.properties");
		try {
			j.getConnection();
		} catch (MobileException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}*/
}
