package com.cg.empmgmt.lab10_2.service;

import java.util.ArrayList;

import com.cg.empmgmt.lab10_2.dao.EmployeeDaoImpl;
import com.cg.empmgmt.lab10_2.dao.IemployeeDao;
import com.cg.empmgmt.lab10_2.dto.Employee1;
import com.cg.empmgmt.lab10_2.exception.EmployeeException;

public class EmployeeServiceImpl implements IemployeeService{

	IemployeeDao iEmployee=new EmployeeDaoImpl();

	@Override
	public boolean addEmployeeDetails(int id, String name, double salary,String designation,String insuranceScheme) throws EmployeeException {
	
		return iEmployee.addEmployee(id, name, salary, designation,insuranceScheme);
	}

	@Override
	public boolean deleteEmployeeDetails(String name) throws EmployeeException {
		// TODO Auto-generated method stub
		return iEmployee.deleteEmployee(name);
	}

	@Override
	public String calculateEmployeeScheme(double salary, String designation) throws EmployeeException {
		// TODO Auto-generated method stub
		
		return iEmployee.calcScheme(salary,designation);
	}

	@Override
	public ArrayList<Employee1> retrieveEmployeeDetails()
			throws EmployeeException {
		return iEmployee.retrieveDetails();
	}

	
	
	

}
