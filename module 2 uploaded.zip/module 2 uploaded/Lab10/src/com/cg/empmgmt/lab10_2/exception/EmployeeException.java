package com.cg.empmgmt.lab10_2.exception;

public class EmployeeException extends Exception{
	
	public EmployeeException(String msg){
		super(msg);
	}
	
	

}
