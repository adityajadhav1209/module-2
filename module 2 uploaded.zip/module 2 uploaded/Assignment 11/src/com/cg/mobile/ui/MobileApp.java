package com.cg.mobile.ui;


import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.cg.mobile.dto.Purchase;
import com.cg.mobile.exception.MobileException;
import com.cg.mobile.service.ImobileService;
import com.cg.mobile.service.MobileServiceImpl;



public class MobileApp {
	
	
	private static final Logger myLogger=Logger.getLogger(MobileApp.class);
	public static void main(String[] args) {
		
		        boolean b;
		        Purchase p=new Purchase();
		     	ImobileService mobService=new MobileServiceImpl();
				int choice=0;
				do{
					printDetail();
				Scanner scr=new Scanner(System.in);
				myLogger.info("Application started");
				System.out.println("Enter the choice");
				choice=scr.nextInt();
				switch(choice){
				case 1://showAll
					try {
						System.out.println(mobService.showAllMobiles());
					} catch (MobileException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						
					}
					
					break;
				case 2:
					try {
						Scanner sc=new Scanner(System.in);
						System.out.println("Enter the first price");
						int price1=sc.nextInt();
						System.out.println("Enter the second price");
						int price2=sc.nextInt();
						System.out.println(mobService.searchMobiles(price1,price2));
						
					} catch (MobileException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						
					}
				
				
				case 3:
					try{
						Scanner sc=new Scanner(System.in);
						
						do{
						
						System.out.println("Enter the name");
						String cname=sc.next();
						p.setCname(cname);
						String patt="[A-Z][a-z]{2,20}";
						Pattern pattern=Pattern.compile(patt);
						Matcher matcher=pattern.matcher(cname);
						b=matcher.matches();
						if(!b){
							System.out.println("Enter the correct name with first letter capital");
						}
						}while(b!=true);
						
						
						do{
						System.out.println("Enter the mail id");
						String mailid=sc.next();
						p.setMailid(mailid);
						String patt="[a-zA-Z\\S_\\.]+@[a-z]+.[a-z]{2,4}";
						Pattern pattern=Pattern.compile(patt);
						Matcher matcher=pattern.matcher(mailid);
						b=matcher.matches();
						if(!b){
							System.out.println("Enter the correct mail id");
						}
						}while(b!=true);
						
						do{
						System.out.println("Enter the phone number");
						String phoneno=sc.next();
						String patt="[7-9][0-9]{9}";
						Pattern pattern=Pattern.compile(patt);
						Matcher matcher=pattern.matcher(phoneno);
						p.setPhoneno(phoneno);
						b=matcher.matches();
						if(!b){
							System.out.println("Enter the correct phone number");
						}
						}while(b!=true);
						
						do{
						System.out.println("Enter the mobile id from the below list");
						System.out.println(mobService.showAllMobiles());
						int mobileid=sc.nextInt();
						p.setMobileid(mobileid);
						String patt="[0-9]{4}";
						Pattern pattern=Pattern.compile(patt);
						Matcher matcher=pattern.matcher(Integer.toString(mobileid));
						
						b=matcher.matches();
						if(!b){
							System.out.println("Enter the correct mobile id");
						}
						}while(b!=true);
						
						int quantity=0;
						do{
						System.out.println("Enter the mobile quantity");
						quantity=sc.nextInt();
						if(quantity<=0){
							System.out.println("Enter the correct quantity");
						}
						}while(quantity<=0);
						p.setPurchaseid(mobService.getPurchaseid());
						int purchaseid=p.getPurchaseid();
						
						
						
						b=mobService.purchaseMobile(p,quantity);
						if(b){
							System.out.println("Mobile purchased successfully");
							}
						else{
							System.out.println("Mobile purchase unsuccessful");
						}
					}catch(MobileException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						
					}
					break;
					
				case 4://delete
					try {
					Scanner sc=new Scanner(System.in);
					System.out.println("Enter the mobile id");
					int id=sc.nextInt();
					b=mobService.deleteMobiles(id);
					if(b){
						System.out.println("Mobile record deleted successfully");
						}
					else{
						System.out.println("Mobile record not deleted");
					}
					} catch (MobileException e) {
						e.printStackTrace();
					}
					break;
					
				case 5:
					try{
					Scanner sc=new Scanner(System.in);
					System.out.println("Enter the mobile id");
					int id=sc.nextInt();
					System.out.println("Enter the mobile quantity");
					int quantity=sc.nextInt();
					
					b=mobService.updateQuantity(id,quantity);
					if(b){
						System.out.println("Quantity updated successfully");
						}
					else{
						System.out.println("Quantity not updated");
					}
					}catch(MobileException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				case 6:
				myLogger.info("Application closed");
					break;
				}
					
					
				}while(choice<6);
	}
        public static void printDetail(){
		System.out.println("**********");
		System.out.println("1. Show All Mobile");
		System.out.println("2. Search Mobile by range");
		System.out.println("3. Purchase Mobile");
		System.out.println("4. Delete mobile data from stock");
		System.out.println("5. Update quantity of mobile");
		System.out.println("6. Exit");
		System.out.println("***********");
	}
}
