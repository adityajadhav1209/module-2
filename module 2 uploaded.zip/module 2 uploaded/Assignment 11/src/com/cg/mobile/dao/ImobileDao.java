package com.cg.mobile.dao;

import java.util.List;

import com.cg.mobile.dto.Mobile;
import com.cg.mobile.dto.Purchase;
import com.cg.mobile.exception.MobileException;

public interface ImobileDao {

	List<Mobile> showAll()throws MobileException;
	boolean deleteMobile(int mobileId)throws MobileException;
	List<Mobile> searchByRange(int start,int end)throws MobileException;
	boolean updateQty(int mobileId,int quantity)throws MobileException;
	 public boolean purchase(Purchase p,int quantity)throws MobileException;
		public int getPId()throws MobileException;
	
}
