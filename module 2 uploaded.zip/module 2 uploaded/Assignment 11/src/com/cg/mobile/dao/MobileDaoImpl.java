package com.cg.mobile.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.mobile.dto.Mobile;
import com.cg.mobile.dto.Purchase;
import com.cg.mobile.exception.MobileException;
import com.cg.mobile.service.ImobileService;
import com.cg.mobile.service.MobileServiceImpl;
import com.cg.mobile.ui.MobileApp;
import com.cg.mobile.util.JdbcUtil;

public class MobileDaoImpl implements ImobileDao{

	Connection con;
	PreparedStatement pst;
	Purchase p=new Purchase();
	  Mobile m=new Mobile();
	private static final Logger myLogger=Logger.getLogger(MobileApp.class);
	
	@Override
	public List<Mobile> showAll()throws MobileException {
	con=JdbcUtil.getConnection();                      
	String query="SELECT * FROM MOBILES";              
	List<Mobile> mList=new ArrayList<Mobile>();
	try {
		pst=con.prepareStatement(query);
		ResultSet rs=pst.executeQuery();
		while(rs.next()){
			int m_id=rs.getInt(1); 
			String m_name=rs.getString(2);             
			double m_price=rs.getDouble(3);
			int m_qty=rs.getInt(4);
			
			Mobile m=new Mobile();
			m.setMobileId(m_id);
			m.setMobileName(m_name);
			m.setPrice(m_price);
			m.setQuantity(m_qty);
			mList.add(m);
			myLogger.info("Data found");
		}
	} catch (SQLException e) {
		myLogger.error("Data not found");
		e.printStackTrace();
		throw new MobileException("Data not Found");
	}finally{
		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
		return mList;
	}

	public boolean deleteMobile(int mobileId) throws MobileException {
		con=JdbcUtil.getConnection();                      
		int rec=0;
		
		String query="DELETE FROM MOBILES WHERE mobileId=?"; 
		try {
			pst=con.prepareStatement(query);
		pst.setInt(1,mobileId);
		rec=pst.executeUpdate();
		if(rec>0){
			return true;
		}
		myLogger.info("Mobile record deleted");
		
		}catch (SQLException e) {
			myLogger.error("Data not deleted");
			e.printStackTrace();
			throw new MobileException("Data not Deleted");
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return false;
	}

	public List<Mobile> searchByRange(int start, int end) throws MobileException {
		con=JdbcUtil.getConnection(); 
		String query="SELECT * FROM MOBILES WHERE price>=? AND price<=?";
		List<Mobile> mList=new ArrayList<Mobile>();
		try {
			pst=con.prepareStatement(query);
		pst.setInt(1,start);
		pst.setInt(2,end);
		ResultSet rs=pst.executeQuery();
		while(rs.next()){
			int m_id=rs.getInt(1); 
			String m_name=rs.getString(2);             
			double m_price=rs.getDouble(3);
			int m_qty=rs.getInt(4);
			Mobile m=new Mobile();
			
			m.setMobileId(m_id);
			m.setMobileName(m_name);
			m.setPrice(m_price);
			m.setQuantity(m_qty);
			mList.add(m);
			myLogger.info("Data Found");
		}
		
	}catch (SQLException e) {
		myLogger.error("Data not deleted");
		e.printStackTrace();
		throw new MobileException("Data not Deleted");
	}finally{
		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
		return mList;
	}

	@Override
	public boolean updateQty(int mobileId, int quantity) throws MobileException {
		con=JdbcUtil.getConnection(); 
		String query=null;
		
		query="UPDATE MOBILES SET QUANTITY=QUANTITY-? WHERE mobileId=?";
		
		int rec=0;
		try {
			pst=con.prepareStatement(query);
			pst.setInt(1,quantity);	
		pst.setInt(2,mobileId);
		rec=pst.executeUpdate();
		if(rec>0){
			return true;
		}
		myLogger.info("Quantity updated successfully");
		}catch (SQLException e) {
			myLogger.error("Failed to update quantity");
			e.printStackTrace();
			throw new MobileException("Data not Updated");
		}finally{
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return false;
	}
	
	@Override
	public boolean purchase(Purchase p,int quantity) throws MobileException {
		con=JdbcUtil.getConnection();
		String query="INSERT INTO PURCHASEDETAILS COLUMNS(PURCHASEID,CNAME,MAILID,PHONENO,PURCHASEDATE,MOBILEID)"
				+"VALUES(?,?,?,?,sysdate,?)";
		try{
			pst=con.prepareStatement(query);
			pst.setInt(1,p.getPurchaseid());
			pst.setString(2,p.getCname());
			pst.setString(3,p.getMailid());
			pst.setString(4,p.getPhoneno());
			pst.setInt(5, p.getMobileid());
		int rec=pst.executeUpdate();
		ImobileService mobService=new MobileServiceImpl();
		mobService.updateQuantity(p.getMobileid(), quantity);
		if(rec>0){
			return true;
		}
		myLogger.info("Mobile purchased successfully");
		
		}catch (SQLException e) {
			myLogger.error("Data not inserted");
		    e.printStackTrace();
		   throw new MobileException("Data not inserted");
	      }finally{
		  try {
			con.close();
		  } catch (SQLException e) {
			e.printStackTrace();
		  }
	    }
		return false;
	}
	
	
	
	@Override
	public int getPId() throws MobileException{
		  int p_id=0;
		 	 
		  con=JdbcUtil.getConnection();
		  String query="SELECT ID_SEQ.NEXTVAL FROM PURCHASEDETAILS";
		  try{
		  pst=con.prepareStatement(query);
		  ResultSet rs=pst.executeQuery();
		    while(rs.next()){
			p_id=rs.getInt(1); 
			p.setPurchaseid(p_id);
			myLogger.info("Purchase Id created successfully");
	     }
		 }catch (SQLException e) {
			 myLogger.error("Failed to generate purchase id");
		    e.printStackTrace();
		   throw new MobileException("Purchase id not generated");
	      }finally{
		  try {
			con.close();
		  } catch (SQLException e) {
			e.printStackTrace();
		  }
	    }
		return p_id;
	}
	
	
      
	}
