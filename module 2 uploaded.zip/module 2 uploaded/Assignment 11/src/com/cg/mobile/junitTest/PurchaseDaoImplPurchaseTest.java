package com.cg.mobile.junitTest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobile.dao.ImobileDao;
import com.cg.mobile.dao.MobileDaoImpl;
import com.cg.mobile.dto.Purchase;
import com.cg.mobile.exception.MobileException;

public class PurchaseDaoImplPurchaseTest {

	Purchase p;
	ImobileDao iService;
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		iService=new MobileDaoImpl();
		p=new Purchase();
	}

	@After
	public void tearDown() throws Exception {
		iService=null;
		p=null;
	}

	@Test
	public void testPurchase() throws MobileException {
		assertNotNull(iService.purchase(p, 5));
	}

}
