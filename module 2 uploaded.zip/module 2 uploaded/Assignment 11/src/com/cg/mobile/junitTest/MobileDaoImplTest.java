package com.cg.mobile.junitTest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobile.dao.ImobileDao;
import com.cg.mobile.dao.MobileDaoImpl;
import com.cg.mobile.exception.MobileException;

public class MobileDaoImplTest {

	ImobileDao iMobile;

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		iMobile=new MobileDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		iMobile=null;
	}

	@Test
	public void testShowAll() throws MobileException {
		assertNotNull(iMobile.showAll());
		
	}

}
