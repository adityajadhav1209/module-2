package com.cg.mobile.junitTest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobile.exception.MobileException;
import com.cg.mobile.service.ImobileService;
import com.cg.mobile.service.MobileServiceImpl;

public class MobileDaoImplDeleteTest {

	ImobileService iService;
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		iService=new MobileServiceImpl();
	}

	@After
	public void tearDown() throws Exception {
		iService=null;
	}

	@Test
	public void testDeleteMobile() throws MobileException {
		assertTrue(iService.deleteMobiles(1001));
	}

}
