package com.cg.mobile.service;

import java.util.Date;
import java.util.List;

import com.cg.mobile.dto.Mobile;
import com.cg.mobile.dto.Purchase;
import com.cg.mobile.exception.MobileException;

public interface ImobileService {
	List<Mobile> showAllMobiles()throws MobileException;
	boolean deleteMobiles(int mobileId)throws MobileException;
	List<Mobile> searchMobiles(int start,int end)throws MobileException;
	boolean updateQuantity(int mobileId,int quantity)throws MobileException;
	boolean purchaseMobile(Purchase p,int quantity)throws MobileException;
    int getPurchaseid()throws MobileException;
	
}
