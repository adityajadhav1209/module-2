package com.cg.mobile.service;

import java.util.Date;
import java.util.List;

import com.cg.mobile.dao.ImobileDao;
import com.cg.mobile.dao.MobileDaoImpl;
import com.cg.mobile.dto.Mobile;
import com.cg.mobile.dto.Purchase;
import com.cg.mobile.exception.MobileException;

public class MobileServiceImpl implements ImobileService{

	ImobileDao imobile=new MobileDaoImpl();
	
	@Override
	public List<Mobile> showAllMobiles() throws MobileException {
		// TODO Auto-generated method stub
		return imobile.showAll();
	}

	@Override
	public boolean deleteMobiles(int mobileId) throws MobileException {
		// TODO Auto-generated method stub
		return imobile.deleteMobile(mobileId);
	}

	@Override
	public List<Mobile> searchMobiles(int start, int end)
			throws MobileException {
		// TODO Auto-generated method stub
		return imobile.searchByRange(start, end);
	}

	@Override
	public boolean updateQuantity(int mobileId, int quantity)
			throws MobileException {
		// TODO Auto-generated method stub
		return imobile.updateQty(mobileId, quantity);
	}

	@Override
	public boolean purchaseMobile(Purchase p,int quantity) throws MobileException {
		
		return imobile.purchase(p,quantity);
	}

	@Override
	public int getPurchaseid() throws MobileException {
		// TODO Auto-generated method stub
		return imobile.getPId();
	}
	
	
}
