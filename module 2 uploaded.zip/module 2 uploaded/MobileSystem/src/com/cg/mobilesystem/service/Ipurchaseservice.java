package com.cg.mobilesystem.service;

import com.cg.mobilesystem.dto.Purchase;
import com.cg.mobilesystem.exception.MobileException;

public interface Ipurchaseservice {

	
	public boolean insertvalue(Purchase P)throws MobileException;
}
