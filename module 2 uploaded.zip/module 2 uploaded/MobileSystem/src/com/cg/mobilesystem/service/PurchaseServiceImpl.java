package com.cg.mobilesystem.service;

import com.cg.mobilesystem.dao.IpurchasesystemDao;
import com.cg.mobilesystem.dao.PurchasesystemDaoImpl;
import com.cg.mobilesystem.dto.Purchase;
import com.cg.mobilesystem.exception.MobileException;

public class PurchaseServiceImpl implements Ipurchaseservice{
IpurchasesystemDao ps = new PurchasesystemDaoImpl();
	@Override
	public boolean insertvalue(Purchase P) throws MobileException {
		
		return ps.insert(P);
	}
	
	
	
	

}
