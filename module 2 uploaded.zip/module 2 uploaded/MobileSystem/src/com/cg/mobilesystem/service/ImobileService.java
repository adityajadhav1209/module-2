package com.cg.mobilesystem.service;

import java.util.List;

import com.cg.mobilesystem.dto.Mobile;
import com.cg.mobilesystem.exception.MobileException;

public interface ImobileService {
	
	List<Mobile>showAllMobiles() throws MobileException;
	boolean deletemobiles(int mobileid)throws MobileException;
	List<Mobile>searchByMobile(int start,int end)throws MobileException;
	boolean updatequantity(int mobileid, int quantity)throws MobileException;
}
