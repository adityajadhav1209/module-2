package com.cg.mobilesystem.service;

import java.util.List;

import com.cg.mobilesystem.dao.ImobilesystemDao;
import com.cg.mobilesystem.dao.MobileDaoImpl;
import com.cg.mobilesystem.dto.Mobile;
import com.cg.mobilesystem.exception.MobileException;

public class MobileServiceImpl implements ImobileService {
	
	ImobilesystemDao imobile = new MobileDaoImpl();

	@Override
	public List<Mobile> showAllMobiles() throws MobileException {
		// TODO Auto-generated method stub
		return imobile.showAll();
	}

	@Override
	public boolean deletemobiles(int mobileid) throws MobileException {
		// TODO Auto-generated method stub
		return imobile.deletemobile(mobileid);
	}

	@Override
	public List<Mobile> searchByMobile(int start, int end)
			throws MobileException {
		// TODO Auto-generated method stub
		return imobile.searchByRange(start, end);
	}

	@Override
	public boolean updatequantity(int mobileid, int quantity)
			throws MobileException {
		// TODO Auto-generated method stub
		return imobile.updateqty(mobileid, quantity);
	}
	
	

}
