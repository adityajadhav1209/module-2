package com.cg.mobilesystem.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobilesystem.dao.IpurchasesystemDao;
import com.cg.mobilesystem.dao.PurchasesystemDaoImpl;
import com.cg.mobilesystem.dto.Purchase;
import com.cg.mobilesystem.exception.MobileException;

public class PurchaseInsertTest {

	IpurchasesystemDao  inst; 
	Purchase p;
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
	
	 inst= new PurchasesystemDaoImpl();
	 p=new Purchase("Aditya","aditya@gmail.com","8976546898", null, 1002,5);
	}

	@After
	public void tearDown() throws Exception {                                                                                                                                           
		inst=null;
		p=null;
	}

	@Test
	public void testinsert() throws MobileException{
		assertTrue(inst.insert(p));
	}

}