package com.cg.mobilesystem.junittest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mobilesystem.dao.ImobilesystemDao;
import com.cg.mobilesystem.dao.MobileDaoImpl;
import com.cg.mobilesystem.dto.Purchase;
import com.cg.mobilesystem.exception.MobileException;

public class TestMobileDaoImpl {

	ImobilesystemDao iMobile;
	
	
	
	

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}
	
	@Before
	public void setup()
	{
		
		iMobile=new MobileDaoImpl();
		
	}

	@After
	public void tearDown() throws Exception {
		
		
		
	}

	@Test
	public void testShowAll() throws MobileException {
		assertNotNull(iMobile.showAll());
	}
	
	
	@Test
	public void testdeletemobile() throws MobileException
	{
		assertTrue(iMobile.deletemobile(1001));
		
		
	}
	
	@Test
	public void testsearchByRange()throws MobileException
	{
		assertNotNull(iMobile.searchByRange(500,50000));
	}
	
	@Test
	public void testupdateqty()throws MobileException
	{
	 assertTrue(iMobile.updateqty(1001,1));
	}
	
	
}
