package com.cg.mobilesystem.ui;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;










import com.cg.mobilesystem.dto.Mobile;
import com.cg.mobilesystem.dto.Purchase;
import com.cg.mobilesystem.exception.MobileException;
import com.cg.mobilesystem.service.*;

public class MobileApp {
	
	private static final Logger myLogger= Logger.getLogger(MobileApp.class);

	public static void main(String[] args) {
		boolean b;
		ImobileService empservice = new MobileServiceImpl();
		Ipurchaseservice purservice = new PurchaseServiceImpl();
		int choice=0;
		do{
			printDetail();
		Scanner sc=new Scanner(System.in);
		choice=sc.nextInt();
		List<Mobile> mlist=new ArrayList<Mobile>();
		switch(choice){
		case 1://ADD
			
			try {
				mlist=empservice.showAllMobiles();
				
				for(Mobile m:mlist)
				{
					System.out.println(m);
				}
				myLogger.info("data found");
			} catch (MobileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			break;
		case 2:
			try {
				Scanner sc1 = new Scanner(System.in);
				System.out.println("enter value 1");
				int value1=sc1.nextInt();
				Scanner sc2 = new Scanner(System.in);
				System.out.println("enter value 2");
				int value2=sc2.nextInt();
				System.out.println(empservice.searchByMobile(value1,value2));
				myLogger.info("data found");
				
			} catch (MobileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
			
		case 3:
			try{
			Purchase p=new Purchase();
			do{
			System.out.println("enter customer name");
			String name=sc.next();
			Pattern cname = Pattern.compile("^[A-Z]{1}[a-zA-Z]{0,19}$");
			Matcher name1 = cname.matcher(name);
			b=name1.matches();
			if(!b){
				
				System.out.println("first letter should be capital");
			}
			}while(b!=true);
			do{
			System.out.println("enter emailid");
			String mail=sc.next();
			Pattern email=Pattern.compile("^[a-zA-Z0-9_-]+@[a-zA-Z]+.[a-zA-Z]+$");
			Matcher mail1=email.matcher(mail);
			b= mail1.matches();
			if(!b){
				
			System.out.println("follow the pattern");}
			}while(b!=true);
			
			do{
			System.out.println("enter phone number");
			String mobno=sc.next();
			Pattern mobile1=Pattern.compile("^(7|8|9)\\d{9}$");
			Matcher mobile2=mobile1.matcher(mobno);
			b= mobile2.matches();
			if(!b){
				
				System.out.println("follow the pattern");}
				}while(b!=true);
			do{
			System.out.println("Please Enter Mobile Id");
			int mobid = sc.nextInt();
			Pattern mobileId = Pattern.compile("^[0-9]{4}$");
			Matcher mobileId1 = mobileId.matcher(String.valueOf(mobid));
			b= mobileId1.matches();
             if(!b){
				
				System.out.println("follow the pattern");
				}
				}while(b!=true);
			
				int quant=0;
			do{
				System.out.println("Please Enter Quantity");
			quant=sc.nextInt();
			if(quant>0){
			p.setQuantity(quant);
			}
			else
			{
				System.out.println("Enter correct quantity");	
			}
			}while(quant<=0);
			
			b=purservice.insertvalue(p);
					if(b){
					System.out.println("data inserted successfully");
					}else{
						
						System.out.println("data not inserted");
					}
			}catch (MobileException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			
			
			break;
			
		case 4:
			
			Scanner sc1 = new Scanner(System.in);
			System.out.println("enter mobile id");
			int value3=sc1.nextInt();
			try {
				System.out.println(empservice.deletemobiles(value3));
				myLogger.info("data deleted");
			} catch (MobileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				myLogger.error("data not deleted");
			}
			break;
		case 5:
			Scanner sc4= new Scanner(System.in);
			System.out.println("enter mobile id");
			int value4=sc.nextInt();
			Scanner sc5= new Scanner(System.in);
			System.out.println("enter quantity");
			int value5=sc5.nextInt();
			try {
				if(value5>0){
				System.out.println(empservice.updatequantity(value4, value5));
				myLogger.info("data updated");
				}
				else
				{
					System.out.println("please enter correct quantity");
				}
			} catch (MobileException e) {
				// TODO Auto-generated catch block
				myLogger.error("data not updated");
				e.printStackTrace();
			}
			break;
			
			
		case 6:
			System.exit(0);
			
		}break;
			
		
		}while(choice!=6);
	}

	//}
	
	public static void printDetail()
	{
		System.out.println("**********");
		System.out.println("1. Show all Mobiles ");
		System.out.println("2. Show Mobiles by range");
		System.out.println("3. Purchase Mobile");
		System.out.println("4. Delete mobile entry");
		System.out.println("5. Update Mobile");
		System.out.println("6. Exit");
		System.out.println("***********");
	}
	
	

	}


