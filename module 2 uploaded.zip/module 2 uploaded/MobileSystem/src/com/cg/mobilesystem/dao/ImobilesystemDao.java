package com.cg.mobilesystem.dao;

import java.util.List;

import com.cg.mobilesystem.dto.Mobile;
import com.cg.mobilesystem.exception.MobileException;

public interface ImobilesystemDao {

	
	List<Mobile>showAll() throws MobileException;
	boolean deletemobile(int mobileid)throws MobileException;
	List<Mobile>searchByRange(int start,int end)throws MobileException;
	boolean updateqty(int mobileid, int quantity)throws MobileException;
	
	
	
	
}
