
package com.cg.mobilesystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.mobilesystem.dto.Mobile;
import com.cg.mobilesystem.exception.MobileException;
import com.cg.mobilesystem.ui.MobileApp;
import com.cg.mobilesystem.util.JdbcUtil;

public class MobileDaoImpl  implements ImobilesystemDao{
    Connection con;
    private static final Logger myLogger= Logger.getLogger(MobileApp.class);
    PreparedStatement pst;
	@Override
	public List<Mobile> showAll() throws MobileException {
		con=JdbcUtil.getConnection1();
		String query="SELECT * from mobiles";
		
		List<Mobile>mList = new ArrayList<Mobile>();
		try {
			pst=con.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
		
			while(rs.next())
			{
				int m_id=rs.getInt(1);
				String m_name=rs.getString(2);
				double m_price=rs.getInt(3);
				int m_quantity=rs.getInt(4);
				
				Mobile m=new Mobile();
				m.setMobileid(m_id);
				m.setName(m_name);
				m.setPrice(m_price);
				m.setQuantity(m_quantity);
				mList.add(m);
				
				
			}
			
		myLogger.info("displaying data");	
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			myLogger.error("unable to display data");
			throw new MobileException("Data not Found");
			
		}
		finally{
			
			try {
				con.close();
				myLogger.info("connection closed");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				myLogger.error("unable to close connection");
				e.printStackTrace();
				
			}
		}
		
		return mList;
		

	}

	@Override
	public boolean deletemobile(int mobileid) throws MobileException {
		 Connection con;
		 con=JdbcUtil.getConnection1();
		 int rec=0;
		 String query="DELETE from mobiles WHERE mobileid=?";
		 try {
			pst=con.prepareStatement(query);
			pst.setInt(1,mobileid);
			rec=pst.executeUpdate();
			if(rec>0)
			{
				
				return true;
			}
			
			
			myLogger.info("data deleted");	
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			myLogger.error("data not deleted");
			e.printStackTrace();
			throw new MobileException("Data not Found");
		}
		 
		 finally{
		
		try {
			con.close();
			pst.close();
			myLogger.info("connection closed");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			myLogger.error("unable to close connection");
			e.printStackTrace();
		}
		 }
		 
		return false;
	}

	@Override
	public List<Mobile> searchByRange(int start, int end) throws MobileException {
		
		con=JdbcUtil.getConnection1();
		String query="SELECT *  from mobiles WHERE price>=? AND price<=?";
		List<Mobile>mList = new ArrayList<Mobile>();
		try {
			pst=con.prepareStatement(query);
			pst.setInt(1, start);
			pst.setInt(2, end);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				int m_id=rs.getInt(1);
				String m_name=rs.getString(2);
				double m_price=rs.getInt(3);
				int m_quantity=rs.getInt(4);
				
				Mobile m=new Mobile();
				m.setMobileid(m_id);
				m.setName(m_name);
				m.setPrice(m_price);
				m.setQuantity(m_quantity);
				mList.add(m);
			}
			
			myLogger.info("data searched");
			
		} 
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			myLogger.error("unable to search data");
			e.printStackTrace();
			throw new MobileException("Data not Found");
		}
		
		
		
		return mList;
	}

	@Override
	public boolean updateqty(int mobileid,int quantity) throws MobileException {
		
		con=JdbcUtil.getConnection1();
		int rec=0;
		String query="UPDATE MOBILES SET QUANTITY=QUANTITY-?WHERE MOBILEID=?";
		try {
			pst=con.prepareStatement(query);
			pst.setInt(1,quantity);
			pst.setInt(2, mobileid);
			rec=pst.executeUpdate();
			if(rec>0)
			{
				
				return true;
				
			}
			myLogger.info("mobile updated successfully");	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			myLogger.error("unable to update");
			throw new MobileException("data not updated");
		}
		return false;
	}

/*	public static void main(String[]args)
	
	{
		
		
		MobileDaoImpl impl= new MobileDaoImpl();
		List<Mobile>mList=impl.showAll();
		for(Mobile m :mList)
		{
			//System.out.println(m);
			
			
		}	
			
		System.out.println(impl.deletemobile(1004));
	}
	*/
/*public static void main(String[]args) throws BookingException
	
	{
		
		
		BusDaoImpl impl= new BusDaoImpl();
		List<BusBean>mList=impl.retrieveBusDetails();
		for(BusBean b :mList)
		{
			System.out.println(b);
			
			
		}	
			
		
	}*/
	
}


