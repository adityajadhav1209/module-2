package com.cg.mobilesystem.dao;

import com.cg.mobilesystem.dto.Purchase;
import com.cg.mobilesystem.exception.MobileException;

public interface IpurchasesystemDao {

	
	public boolean insert(Purchase P)throws MobileException;
}
