package com.cg.mobilesystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.mobilesystem.dto.Purchase;
import com.cg.mobilesystem.exception.MobileException;
import com.cg.mobilesystem.util.JdbcUtil;

public class PurchasesystemDaoImpl implements IpurchasesystemDao {

	 Connection con;
	    PreparedStatement pst;
	    ImobilesystemDao upt = new MobileDaoImpl();
		@Override
		public boolean insert(Purchase p) {
			 con=JdbcUtil.getConnection1();
			 int rec=0;
			 String query="Insert into purchasedetails values (seq_id.NEXTVAL,?,?,?,sysdate,?)";
			 try {
				pst=con.prepareStatement(query);
				pst.setString(1,p.getCname());
				pst.setString(2,p.getMailid());
				pst.setString(3,p.getPhoneno());
				pst.setInt(4,p.getMobileid());
				rec=pst.executeUpdate();
				if(rec>0)
				{
					upt.updateqty(p.getMobileid(), p.getQuantity());
					return true;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (MobileException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			 
			
			return false;
		}
		
	
}
