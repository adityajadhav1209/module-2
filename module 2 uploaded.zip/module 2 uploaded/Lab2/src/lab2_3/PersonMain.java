package lab2_3;

public class PersonMain {

	public static void main(String[] args) {
		Person person=new Person("Aditya", "Jadhav", 'M');
		System.out.println("First Name:"+person.getFirstName());
		System.out.println("Last Name:"+person.getLastName());
		System.out.println("Gender:"+person.getGender());

	}

}
