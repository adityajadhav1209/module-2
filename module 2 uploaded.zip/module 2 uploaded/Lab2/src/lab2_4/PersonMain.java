package lab2_4;

public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person person=new Person("Aditya", "Jadhav", 'M',"7208030599" );
		System.out.println("First Name:"+person.getFirstName());
		System.out.println("Last Name:"+person.getLastName());
		System.out.println("Gender:"+person.getGender());
		System.out.println("Phone Number:"+person.getPhno());
	}

}
