package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.util.JdbcUtil;





public class BusDaoImpl implements IbusDao{
	 Connection con;
	 PreparedStatement pst;
	 BookingBean bookingBean=new BookingBean();
	
	 private static final Logger myLogger= Logger.getLogger(BusDaoImpl.class);
	@Override
	public ArrayList<BusBean> retrieveBusDetails() throws BookingException {
		con=JdbcUtil.getConnection1();
		String query="SELECT * from BusDetails";
		ArrayList<BusBean>mList = new ArrayList<BusBean>();
		try {
			pst=con.prepareStatement(query);
			ResultSet rs=pst.executeQuery();
			
			while(rs.next())
			{
				int m_id=rs.getInt(1);
				String m_type=rs.getString(2);
				String from_stop=rs.getString(3);
				String to_stop=rs.getString(4);
				int m_fare=rs.getInt(5);
				int m_seats=rs.getInt(6);
				
				Date m_date = rs.getDate(7);
				
				BusBean b=new BusBean();
				
				b.setBusId(m_id);
				b.setBusType(m_type);
				b.setFromStop(from_stop);
				b.setToStop(to_stop);
				b.setFare(m_fare);
				b.setAvailabeSeats(m_seats);
				b.setDateOfJourney((java.sql.Date) m_date);
				
				
				mList.add(b);
				myLogger.info("details showing");
				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			myLogger.error("failed to enter");
			throw new BookingException("Data not Found");
		}finally
		
		{
			
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return mList;
	}

	@Override
	public int bookTicket(BookingBean bookingBean) throws BookingException {
		Connection con;
	    PreparedStatement pst;
	    con=JdbcUtil.getConnection1();
		 int rec=0;
		 String query="Insert into BookingDetails values (Booking_Id_Seq.NEXTVAL,?,?,?)";
		 
		 try {
			pst=con.prepareStatement(query);
			pst.setString(1,bookingBean.getCustId());
			pst.setInt(2,bookingBean. getBusId());
			pst.setInt(3,bookingBean. getNoOfSeat());
			rec=pst.executeUpdate();
			 BusDaoImpl bs= new BusDaoImpl();
			bs.updateseat(bookingBean.getBusId(),bookingBean.getNoOfSeat());
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			myLogger.error("failed");
			
		}
		 BusDaoImpl bs= new BusDaoImpl();
		 
		return bs.getBookingId(bookingBean. getBookingId());
	}

	@Override
	public boolean updateseat(int busId, int noOfSeat) throws BookingException {
		
		con=JdbcUtil.getConnection1();
		int rec=0;
		String query="UPDATE BusDetails SET AVAILABLESEATS=AVAILABLESEATS-?WHERE BUSID=?";
		try {
			pst=con.prepareStatement(query);
			pst.setInt(1,noOfSeat);
			pst.setInt(2, busId);
			rec=pst.executeUpdate();
			
			if(rec>0)
			{
				return true;
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
		
	}

	

	@Override
	public int getBookingId(int busId) throws BookingException {
		con=JdbcUtil.getConnection1();
		String query="SELECT BOOKINGID from BOOKINGDetails WHERE BUSID=?";
		
		int booking_id=0;
		try {
			pst=con.prepareStatement(query);
			pst.setInt(1,busId);
			
			ResultSet rs=pst.executeQuery();
			while(rs.next())
					
			{
				booking_id=rs.getInt(1);
				
			}
			BookingBean bookingBean=new BookingBean();
			bookingBean.setBookingId(booking_id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return bookingBean.getBookingId();
	}

	
	
	
	

}
