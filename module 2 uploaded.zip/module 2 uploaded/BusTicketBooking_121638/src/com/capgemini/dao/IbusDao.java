package com.capgemini.dao;

import java.util.ArrayList;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;


public interface IbusDao {

	
	ArrayList<BusBean>retrieveBusDetails()throws BookingException;
	int bookTicket(BookingBean bookingBean)throws BookingException;
	boolean updateseat(int busId, int noOfSeat)throws BookingException;
    
	int getBookingId(int busId) throws BookingException;
}
