package com.capgemini.bean;

public class BookingBean {

	private int bookingId;
	private String custId;
	private int busId;
	private int noOfSeat;
	public BookingBean() {
		super();
	}
	public BookingBean(int bookingId, String custId, int busId, int noOfSeat) {
		super();
		this.bookingId = bookingId;
		this.custId = custId;
		this.busId = busId;
		this.noOfSeat = noOfSeat;
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public int getBusId() {
		return busId;
	}
	public void setBusId(int busId) {
		this.busId = busId;
	}
	public int getNoOfSeat() {
		return noOfSeat;
	}
	public void setNoOfSeat(int noOfSeat) {
		this.noOfSeat = noOfSeat;
	}
	@Override
	public String toString() {
		return "BookingBean [bookingId=" + bookingId + ", custId=" + custId
				+ ", busId=" + busId + ", noOfSeat=" + noOfSeat + "]";
	}
	
	
}
