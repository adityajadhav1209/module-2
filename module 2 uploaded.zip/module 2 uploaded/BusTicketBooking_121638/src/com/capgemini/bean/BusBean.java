package com.capgemini.bean;

import java.sql.Date;
import java.time.LocalDate;

public class BusBean {
	
	private int busId;
	private String busType;
	private String fromStop;
	private String toStop;
	private int fare;
	private int availabeSeats;
	private Date dateOfJourney;
	public BusBean() {
		super();
	}
	public BusBean(int busId, String busType, String fromStop, String toStop,
			int fare, int availabeSeats, Date dateOfJourney) {
		super();
		this.busId = busId;
		this.busType = busType;
		this.fromStop = fromStop;
		this.toStop = toStop;
		this.fare = fare;
		this.availabeSeats = availabeSeats;
		this.dateOfJourney = dateOfJourney;
	}
	public int getBusId() {
		return busId;
	}
	public void setBusId(int busId) {
		this.busId = busId;
	}
	public String getBusType() {
		return busType;
	}
	public void setBusType(String busType) {
		this.busType = busType;
	}
	public String getFromStop() {
		return fromStop;
	}
	public void setFromStop(String fromStop) {
		this.fromStop = fromStop;
	}
	public String getToStop() {
		return toStop;
	}
	public void setToStop(String toStop) {
		this.toStop = toStop;
	}
	public int getFare() {
		return fare;
	}
	public void setFare(int fare) {
		this.fare = fare;
	}
	public int getAvailabeSeats() {
		return availabeSeats;
	}
	public void setAvailabeSeats(int availabeSeats) {
		this.availabeSeats = availabeSeats;
	}
	public Date getDateOfJourney() {
		return dateOfJourney;
	}
	public void setDateOfJourney(Date dateOfJourney) {
		this.dateOfJourney = dateOfJourney;
	}
	@Override
	public String toString() {
		return "BusBean [busId=" + busId + ", busType=" + busType
				+ ", fromStop=" + fromStop + ", toStop=" + toStop + ", fare="
				+ fare + ", availabeSeats=" + availabeSeats
				+ ", dateOfJourney=" + dateOfJourney + "]";
	}
	
	
	
	
	

	
	
	
	
}
