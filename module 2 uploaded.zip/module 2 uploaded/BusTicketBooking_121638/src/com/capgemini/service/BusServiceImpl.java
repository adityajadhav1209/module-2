package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.dao.BusDaoImpl;
import com.capgemini.dao.IbusDao;

public class BusServiceImpl implements IbusService{
    IbusDao ib = new BusDaoImpl();
	@Override
	public ArrayList<BusBean> retrieveBusDetailsBooking()
			throws BookingException {
		// TODO Auto-generated method stub
		return ib.retrieveBusDetails();
	}

	@Override
	public int bookTicketSeats(BookingBean bookingBean) throws BookingException {
		// TODO Auto-generated method stub
		return ib.bookTicket(bookingBean);
	}

	@Override
	public boolean updateseats(int busId, int noOfSeat) throws BookingException {
		// TODO Auto-generated method stub
		return ib.updateseat(busId, noOfSeat);
	}




}
