package com.capgemini.service;

import java.util.ArrayList;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;

public interface IbusService {
	ArrayList<BusBean>retrieveBusDetailsBooking()throws BookingException;
	int bookTicketSeats(BookingBean bookingBean)throws BookingException;
	boolean updateseats(int busId, int noOfSeat)throws BookingException;
}
