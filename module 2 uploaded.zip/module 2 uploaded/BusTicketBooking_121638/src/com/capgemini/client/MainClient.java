package com.capgemini.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;




import org.apache.log4j.Logger;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.bean.BusBean;
import com.capgemini.service.BusServiceImpl;
import com.capgemini.service.IbusService;






public class MainClient {

	public static void main(String[] args) {
		boolean a;
		IbusService bp = new BusServiceImpl();
		int choice=0;
		do{
		printDetail();
		Scanner sc=new Scanner(System.in);
		choice=sc.nextInt();
		ArrayList<BusBean> mlist=new ArrayList<BusBean>();
		switch(choice)
		{
		case 1:
			
			try {
				mlist=bp.retrieveBusDetailsBooking();
				for(BusBean b:mlist){
					
					
					System.out.println((b));
				}
			} catch (BookingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}break;
			
		case 2:
			
			BookingBean bookingBean = new BookingBean();
			int count=0;
				System.out.println("enter customer id");
				String name=sc.next();
				Pattern cname = Pattern.compile("^[A-Z]{1}[0-9]{6}$");
				Matcher name1 = cname.matcher(name);
				if(name1.matches()){
					bookingBean.setCustId(name);
					count++;
				}
				
			
				System.out.println("enter bus id");
				int id=sc.nextInt();
				Pattern id_m = Pattern.compile("^[1|2|3]$");
				Matcher id1 = cname.matcher(name);
				if(id1.matches()){
					bookingBean.setBusId(id);
					count++;
				}
				
				System.out.println("enter number of seats");
				int m_seat=sc.nextInt();
				
				if(m_seat>0 && m_seat<30)
				{
					bookingBean.setNoOfSeat(m_seat);
					
					
					count++;
				}
				
				else{
					
					System.out.println("enter number of seats in range");
				}
				
				if(count==3){
					int val;
					try {
						val = bp.bookTicketSeats(bookingBean);
						System.out.println( val);
					} catch (BookingException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		
		
		}
				else{
					
				System.out.println("enter the details again");
				}break;
				
				
		case 3:
			System.exit(0);
				}break;
		
		
	
}while(choice!=3);
}
	public static void printDetail()
	{
		System.out.println("**********");
		System.out.println("1. Show all Bus Details ");
		System.out.println("2. Book Ticket");
		System.out.println("3.Exit");
		System.out.println("**********");
	
	}
	
}