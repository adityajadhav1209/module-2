package com.capgemini.junitTest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.Exception.BookingException;
import com.capgemini.bean.BookingBean;
import com.capgemini.dao.BusDaoImpl;
import com.capgemini.dao.IbusDao;

public class BookingInsert {
IbusDao bus;
BookingBean bookingBean;

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		bus=new BusDaoImpl();
		bookingBean= new BookingBean(0, "A123456",2,2);
	}

	@After
	public void tearDown() throws Exception {
		bus=null;
		bookingBean=null;
	}

	@Test
	public void testbookTicket() throws BookingException {
	equals(bus.bookTicket(bookingBean));
	}

}
