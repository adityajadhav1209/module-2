package com.capgemini.junitTest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.Exception.BookingException;
import com.capgemini.dao.BusDaoImpl;
import com.capgemini.dao.IbusDao;

public class BusDetailsTest {
	IbusDao bus;
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		bus=new BusDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		bus=null;
	}

	@Test
	public void testretrieveBusDetails() throws BookingException {
		assertNotNull(bus.retrieveBusDetails());
	}

}
