package com.capgemini.util;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.Exception.BookingException;



public class JdbcUtil {
	
	private static final Logger mylogger=Logger.getLogger(JdbcUtil.class);
	
	public static Properties loadProperty()
	{
		Properties prop=new Properties();
		InputStream in=null;
		 try {
			in= new FileInputStream("resources\\oracle.properties");
			prop.load(in);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return prop;
	}
		 public static Connection getConnection1()
		 {
			 Connection con=null;
			 Properties prop=loadProperty();
			 String url=prop.getProperty("oracle.url");
			 String driver=prop.getProperty("oracle.driver");
			 String user=prop.getProperty("oracle.uname");
			 String Password=prop.getProperty("oracle.upass");
			 
			 
			 
			 //Class.forName("oracle.jdbc.driver.OracleDriver");
			 try {
				Class.forName(driver);
				mylogger.info("driver is loaded");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				mylogger.error("driver is not loaded");
			}
			// String url="jdbc:oracle:thin:@10.125.6.62:1521:orcl11g" ;
			 try
			 {
				 con=DriverManager.getConnection(url, user, Password);
				mylogger.info("connected to database");
			 }
			 catch(SQLException e)
			 
			 {
				mylogger.error("Not connected");
				
			 }
			 return con;
			 	 
		 }		


	public static void main(String[] args) throws BookingException {
		JdbcUtil j=new JdbcUtil();
		PropertyConfigurator.configure("log4j.properties");
		j.getConnection1();

	}

}
