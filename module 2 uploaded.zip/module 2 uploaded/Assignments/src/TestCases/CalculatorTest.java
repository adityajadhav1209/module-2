package TestCases;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Test;
import org.junit.runners.Parameterized;
@RunWith(Parameterized.class)
public class CalculatorTest {
	
	private int input1;
	private int input2;
	private int expected;
	@Parameterized.Parameters
	
	
	 public static Collection data()
	{
		
		return Arrays.asList(new Object[][]{{1,2,3},{3,4,5},{5,6,7}});
	}
	
	

	public CalculatorTest(int input1, int input2, int expected) {
		super();
		this.input1 = input1;
		this.input2 = input2;
		this.expected = expected;
	}



	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAdd() {
		assertEquals(input1,input2,expected);
	}

	@Test
	public void testSubtract() {
		assertEquals(input1,input2,expected);
		
	}

}
