package Lab4;

public class Account {
	
	
	private long accNum;
	private double balance;
	private Person accHolder; 
	static int count=10000;
	public long getAccNum() {
		return accNum;
	}
	
	//public double getBalance() {
		//return balance;
	//}
	/*public void setBalance(double balance) {
		this.balance = balance;
	}*/
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	public Account( double balance) {
		super();
		count++;
		
		this.balance = balance;
		
	}
	public Account() {
		super();
	}
	

	public void deposit(double x){
		
		balance+=x;
		
	}
	public void withdraw(double y){
		
	balance-=y;	
		
	}
	
	public double getBalance(){
		return balance;
		
		
		
	}
	@Override
	public String toString() {
		return "Account [accNum=" + accNum + ", balance=" + balance
				+ ", accHolder=" + accHolder + "]";
	}


}
