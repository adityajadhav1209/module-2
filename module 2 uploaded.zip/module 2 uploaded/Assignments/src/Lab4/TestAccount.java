package Lab4;

public class TestAccount {

	public static void main(String[] args) {
		
		
		
		
		Person smith=new Person("smith",23);
		Person kathy=new Person("kathy",25);
		Account smithAccount = new Account(2000);
		smithAccount.setAccHolder(smith);
		smithAccount.deposit(2000);
		
		Account kathyAccount = new Account(3000);
		kathyAccount.setAccHolder(kathy);
		kathyAccount.withdraw(2000);
		
		System.out.println("kathy balance is:"+kathyAccount.getBalance());
		System.out.println("smith balance is:"+smithAccount.getBalance());
		
		
		System.out.println(smith);
		System.out.println(kathy);
		
		System.out.println(kathyAccount);
		System.out.println(smithAccount);
	}
	
	

}
