package Lab5_3;

public class AccountImpl extends Account {
	
	
	
	 public AccountImpl(double balance) {
			super(balance);	

}

	@Override
	public void withDraw(double x) {
		// TODO Auto-generated method stub
		
	}
}
