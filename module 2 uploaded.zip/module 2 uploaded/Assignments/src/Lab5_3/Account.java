package Lab5_3;

public abstract class Account {
	
	protected long accNum;
	protected double balance;
	protected Person accHolder;
		static int count=10000;
		
		public long getAccNum() {
			return accNum;
		}
			
		public Person getAccHolder() {
			return accHolder;
		}
		public void setAccHolder(Person accHolder) {
			this.accHolder = accHolder;
		}
		public Account(double balance) {
			super();
			count++;
			this.balance = balance;
			this.accNum = count;
		}
		
		
		
		

		public void setBalance(double balance) {
			this.balance = balance;
		}

		public void deposit(double x){
			balance=balance+x;
			
		}
		
		public abstract void withDraw(double x);
		
		public double getBalance(){
			return balance;
		}

		public String toString() {
			return "Account [accNum=" + accNum + ", balance=" + balance
					+ ", accHolder=" + accHolder + "]";
		}
	
	
	
	
	
	
	

}
