package Lab5_3;

public class PersonMain {

	public static void main(String[] args) {
		Person smith=new Person("Smith",23);
		Person kathy=new Person("Kathy",25);
		
		
	    Account smithAccount=new AccountImpl(5000);
		smithAccount.setAccHolder(smith);
		System.out.println(smithAccount);
		
		Account kathyAccount=new AccountImpl(2000);
		kathyAccount.setAccHolder(kathy);
		System.out.println(kathyAccount);
		
		smithAccount.deposit(2000);
		kathyAccount.withDraw(1000);
		
		
		System.out.println("Deposited successfully. Smith's Balance is "+smithAccount.getBalance());
		System.out.println("Cash withdrawn successfully. Balance is "+kathyAccount.getBalance());
	}

}
