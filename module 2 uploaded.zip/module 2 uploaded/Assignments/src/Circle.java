
public class Circle extends Shape {
	
	private int radius;
	
	

	public Circle() {
		super();
	}
	



	public Circle(int radius) {
		super();
		this.radius = 2;
	}




	@Override
	public void draw() {
		System.out.println("circle is drawn");
		
	}
	
	

}
