
import java.util.Scanner; 

public class PersonMain {
	
	


	public static void main(String[] args) {
		Gender gender=null;
		Person person=new Person();
		person.setFirstName("Aditya");
		person.setLastName("Jadhav");
		
		System.out.println("Enter phonenumber");
		Scanner sc=new Scanner(System.in); 
		String phno=sc.nextLine();
		person.setPhonenumber(phno);
		System.out.println("enter gender:");
		String m_gender=sc.nextLine();
		gender=Gender.valueOf(m_gender);
		person.setGender(gender);
		person.show();
		
		sc.close();

	}

}
