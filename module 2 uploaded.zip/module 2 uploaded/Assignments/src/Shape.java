
abstract public class Shape {
	public abstract void draw();

}
