import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Properties;




public class PropertiesDemo {
	
	
	
	public static void writeProperties()
	{
		
		Properties prop = new Properties();
		OutputStream output = null;
		try {
			output = new FileOutputStream("oracle.properties");
		 
		prop.setProperty("oracle.driver", "oracle.jdbc.driver.OracleDriver");
		prop.setProperty("oracle.url", "jdbc:oracle:thin:@localhost:1521:xe");
		prop.setProperty("oracle.uname", "adjadhav");
		prop.setProperty("oracle.upass", "igate@123");
		
		
		prop.store(output,null);
		//prop.list(System.out);
		}
		catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println(e);
			e.printStackTrace();
		}
	}

	
	public static void  loadProperties()
	{
		Properties prop = new Properties();
		InputStream input = null;
		try {
			
			input = new FileInputStream("oracle.properties");
			prop.load(input);
			
			System.out.println(prop.getProperty("oracle.driver"));
		   System.out.println(prop.getProperty("oracle.url"));
			System.out.println(prop.getProperty("oracle.uname"));
			System.out.println(prop.getProperty("oracle.upass"));
			
		} catch (FileNotFoundException e) {
			System.out.println(e);
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println(e);
			e.printStackTrace();
		}finally{
			
			if(input != null){
				
				try {
					input.close();
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			}
		}
		
		}
		
	
	public static void main(String[] args) {
		
		writeProperties();
		loadProperties();
		
	}

}
