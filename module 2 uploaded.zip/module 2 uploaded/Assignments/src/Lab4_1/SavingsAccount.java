 package Lab4_1;

public class SavingsAccount extends Account{
	
	public double Balance=10000;
	public final double minBalance=500;
	

public void withdraw(double amt){
	
	Balance=Balance-amt;
	if(Balance<=minBalance){
		
		
		System.out.println("cannot Withdraw");
		}	
	else
		System.out.println("Balance is:" +Balance);
	
	
}
	


}

