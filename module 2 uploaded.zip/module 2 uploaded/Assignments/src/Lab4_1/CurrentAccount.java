package Lab4_1;

public class CurrentAccount extends Account {
	
	
	public int overDraftLimit=10000;
	public int x=0;
	public int Balance=10000;
	

	public boolean withDraw(int amt){
		
		x=amt-Balance;
		if(x<=overDraftLimit){
			if(x<0){
				x=-x;
			}
			return true;
			
		}
		else{
			return false;
			
		}
	}
	

}
