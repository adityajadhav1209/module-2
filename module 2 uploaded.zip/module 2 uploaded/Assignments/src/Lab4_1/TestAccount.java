package Lab4_1;

public class TestAccount {

	public static void main(String[] args) {
		
		
		SavingsAccount sa=new SavingsAccount();
		CurrentAccount ca=new CurrentAccount();
		System.out.println("From Savings Account");
		sa.withdraw(1000);
		
		System.out.println("From Current Account");
		if(ca.withDraw(15000)){
			System.out.println("Balance is Rs.0. Over draft amount is "+ca.x);
		}
		else{
			System.out.println("Over draft limit exceeded. can't proceed with the transaction");
		}
	}


	}


