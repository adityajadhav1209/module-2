package Lab4_1;

public class Account {

	public void withDraw(){
		System.out.println("Withdrawing cash");
	}
}
