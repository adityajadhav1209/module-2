package Lab6_1;

import javax.naming.NameNotFoundException;



public class Person {
	

	String firstName;
	String lastName;
	String Gender;
	 
	
	
	public Person() {
		super();
	}



	public Person(String firstName, String lastName, String gender) throws NameNotFoundException {
		super();
		
		if(firstName.length()!=0){
		 
		this.firstName = firstName;
		}
		else{
			
			throw new NameNotFoundException("Enter the first name");
		}
		
		
		if(lastName.length()!=0)
		
		{
		this.lastName = lastName;
		}
		else
		{
			throw new NameNotFoundException("Enter the first name");	
		}
		Gender = gender;
	}



	public String getFirstName() {
		return firstName;
	}



	public void setFirstName(String firstName) throws NameNotFoundException {
		if(firstName.length()!=0){
			 
			this.firstName = firstName;
			}
			else{
				
				throw new NameNotFoundException("Enter the first name");
			}
	}



	public String getLastName() {
		return lastName;
	}



	public void setLastName(String lastName) throws NameNotFoundException {
		if(lastName.length()!=0)
			
		{
		this.lastName = lastName;
		}
		else
		{
			throw new NameNotFoundException("Enter the first name");	
		}
	}



	public String getGender() {
		return Gender;
	}



	public void setGender(String gender) {
		this.Gender = gender;
	}

	

}
