package Lab6_1;

import java.util.Scanner;

import javax.naming.NameNotFoundException;

public class PersonMain {

	public static void main(String[] args) throws NameNotFoundException {
		
		
		Person person = new Person();
		Scanner sc = new Scanner(System.in);
		String first="";
		String last="";
		String m_gender="";
		System.out.println("Please Enter First Name");
		first=sc.nextLine();
		person.setFirstName(first);
		System.out.println("Please Enter LAst Name");
		last=sc.nextLine();
		person.setLastName(last);
		System.out.println("Please Enter Gender");
		m_gender=sc.nextLine();
		person.setGender(m_gender);
		System.out.println("First Name:"+person.getFirstName());
		System.out.println("Last Name:"+person.getLastName());
		System.out.println("Gender:"+person.getGender());
		
		
		
		
		
	}

}
