package Assignment8;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Number {

	public static void main(String[] args) {
		
		try {
			File text = new File("d:\\numbers.txt");
			Scanner sc;
			sc = new Scanner(text);
			
	        while(sc.hasNextLine()){
	            String line = sc.nextLine();
	            String b[]=line.split(",");
	            for(int i=0;i<b.length;i++)
	            { 
	            	int out= Integer.valueOf(b[i]).intValue();
	            	if(out==0)
	            	{
	        
	            	}
	            	else if(out%2==0)
	            	{
	            	System.out.println(out);
	            	}
	            	}
	        }
	        sc.close();
		}
		catch(Exception ex){
			ex.printStackTrace();	
		}
		}
}
	            
	            		
	            	
	            
	            
	           
		 
	        
	       
		
       
		


		


