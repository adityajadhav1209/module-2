package Assignment8;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;



public class Lab8_1 {
	
	FileInputStream fromFile;
	FileOutputStream toFile;
	
	
	public void init(String arg1, String arg2){
		
		try {
			fromFile=new FileInputStream(new File(arg1));
		} catch (FileNotFoundException e) {
			System.out.println(e);
			
		}
		try {
			toFile=new FileOutputStream(new File(arg2));
		} catch (FileNotFoundException e) {
			System.out.println(e);
			
		}
			 
	}
	
	public void copyContents() {
		
		 
		try {
			
			int currentByte = fromFile.available();
			int readCount = 0;

		    int byteContainer[] = new int[currentByte];
		    
		    
		    while(readCount<currentByte)
            {
            	byteContainer[readCount]= fromFile.read();
            	readCount++;		
            }           
			for(int i=currentByte-1;i>=0;i--)
			{
				toFile.write(byteContainer[i]);
				
			}
		} catch (IOException e) {
			
			System.out.println(e);
		}
		    
		
		
		
	}
	
	public void closeFiles() {

		try {
			fromFile.close();
			toFile.close();
		} catch (IOException e) {
			System.out.println(e);
			return;
		}
		
			
		} 
		
	

	public static void main(String[] args) {
		
		Lab8_1 c1 = new Lab8_1();
		c1.init(args[0], args[1]);
		c1.copyContents();
		c1.closeFiles();

	}

}
