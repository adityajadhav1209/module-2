import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;


public class productTest {

product P1;
	
	
	@Before
	public void setUp() throws Exception {
		
		P1=new product(1,"pen",10,10);
	}

	@After
	public void tearDown() throws Exception {
		
		P1=null;
	}

	@Test
	public void testCalculateCost() {
		fail("Not yet implemented");
		
		assertEquals(90.0,P1.calculateCost(),0.0 );
	}
	
	
	
	
}
