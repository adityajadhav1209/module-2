package Lab7_1;
import java.util.Arrays;
import java.util.Scanner;
public class ProductName {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		String names[]=new String[5];
	 
		for(int i=0;i<names.length;i++)
		{
			names[i]=sc.nextLine();
		}
		
		System.out.println("After sorting");
		Arrays.sort(names);
		
		for(String s:names){
			
			
			
			System.out.println(s);
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
