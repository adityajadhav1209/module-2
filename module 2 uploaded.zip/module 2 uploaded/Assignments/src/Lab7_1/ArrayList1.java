package Lab7_1;

import java.util.ArrayList;
import java.util.Collections;

public class ArrayList1 {

	public static void main(String[] args) {
		
		ArrayList<String> aList = new ArrayList<>();
		aList.add("sauce");
		aList.add("biscuits");
		aList.add("masala");
		aList.add("soap");
		 for(String b:aList){
				
				
				
				System.out.println(b);
			}
		
		System.out.println("After sorting");
		Collections.sort(aList);
		
   for(String s:aList){
			
			
			
			System.out.println(s);
		}
		
			

	}

}
