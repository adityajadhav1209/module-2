package com.cg.eis.service;

import java.util.Scanner;

import com.cg.eis.bean.Employee;

public class EmployeeServiceImp1 implements EmployeeService{

	Employee e;
	
	@Override
	public void inputEmployee() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter id");
		int id = sc.nextInt();
		System.out.println("Enter name");
		String name = sc.next();
		System.out.println("Enter salary");
		double salary = sc.nextDouble();
		System.out.println("Enter designation");
		String designation = sc.next();
		sc.close();
		e=new Employee(id,name,salary,designation);
		
			
	}

	

	@Override
	public void findInsuranceScheme() {
 
	double salary=e.getSalary();
	String  designation=e.getDesignation();
	
		if(salary>5000 && salary<20000 && designation.equals("System Associate"))
			
		{
			System.out.println("Scheme C");
			
		}
		else if(salary>=20000 && salary<40000 && designation.equals("Programmer"))
		{
			System.out.println("Scheme B");
		}
		else if (salary>=40000 && designation.equals("Manager"))
		{
			System.out.println("Scheme A");
		}
		else if(salary<5000 && designation.equals("Clerk"))
			
		{
			System.out.println("NO scheme");
		}
		
	}

	@Override
	public void displayDetails() {
	  System.out.println(e);
		
	}



}
