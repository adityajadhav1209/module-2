package com.cg.eis.pl;

import com.cg.eis.service.EmployeeServiceImp1;

public class EmpApp {
	
	
	
	public static void main(String[]args)
	{
		EmployeeServiceImp1 emp = new EmployeeServiceImp1();
		emp.inputEmployee();
		emp.findInsuranceScheme();
		emp.displayDetails();
		
	}

}
