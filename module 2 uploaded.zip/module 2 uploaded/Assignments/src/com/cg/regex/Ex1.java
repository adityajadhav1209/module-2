package com.cg.regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Ex1 {

	public static void main(String[] args) {

//String s = "123_4567_741";  //straing contains only underscore
//String s = "123 4567_741"; //string contain space and underscore
//String s = "aAsD12345678";   // string contains any number of character
		String s = "adityajadhav1209@gmail.com";
//Pattern pattern=Pattern.compile("(^[0-9]{3}_[0-9]{4}_[1-9]{3})"); //put only underscore
//Pattern pattern=Pattern.compile("(^[0-9]{3}(_|\\s)[0-9]{4}(_|\\s)[1-9]{3})"); //put either space or underscore
//Pattern pattern=Pattern.compile("([a-zA-Z0-9]*)");//any number of characters
//Pattern pattern=Pattern.compile("[\\S]*");  //any number of characters
Pattern pattern=Pattern.compile("^[a-zA-Z0-9_-]+@[a-zA-Z]+.[a-zA-Z]+$"); //email id pattern
Matcher matcher=pattern.matcher(s);
System.out.println(matcher.matches());

	}

}
