package lab6_2;

public class Validation {

	public static void main(String[] args) throws AgeException {
		Person person=new Person("Aditya",18);
		System.out.println("Person name is "+person.getName()+"\n"+"Age is "+person.getAge());

	}

}
