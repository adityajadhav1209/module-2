package Lab3;

import java.util.Scanner;

public class PersonMain {

	public static void main(String[] args) {
		Person3_7 p1=new Person3_7();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the date in this format 'yyyy-MM-dd'");
		String dob=sc.next();
		System.out.println("Enter the name");
		String firstname=sc.next();
		p1.setFirstname(firstname);
		System.out.println("Enter the last name");
		String lastname=sc.next();
		p1.setLastname(lastname);
		sc.close();
		
	
		p1.calculateAge(dob);
		
		
		
		
		

	}

}
