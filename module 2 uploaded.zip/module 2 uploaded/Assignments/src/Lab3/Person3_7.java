package Lab3;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class Person3_7 {

	public String firstname;
	public String lastname;
	public String dob;
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	
	
	

public void calculateAge(String dob) {
	
	
	DateTimeFormatter formatter=DateTimeFormatter.ofPattern("yyyy-MM-dd");
	
	LocalDate date2=LocalDate.parse(dob,formatter);
	LocalDate currentDate=LocalDate.now();
	Period period=date2.until(currentDate);
	System.out.println(getFullName());
	System.out.println("Age is:");
	System.out.println("Years "+period.getYears());
	
}
 public  String getFullName()
 {
	 return(getFirstname() +" " + getLastname());
 }

}