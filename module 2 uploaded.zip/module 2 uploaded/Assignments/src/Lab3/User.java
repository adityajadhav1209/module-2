package Lab3;

import java.util.Scanner;

public class User {
	
	String result;
	public String addString(String string,int choice){
		result=string+string;
		return result;
	}
	
	public String replaceOdd(String string,int choice){
	  StringBuilder sb=new StringBuilder(string);
		for(int i=0;i<sb.length();i++){
			
			if(i%2!=0){
				sb.replace(i, i+1, "#");
			}
		}
		result=new String(sb);
		return result;
	}
	
	public String removeDuplicate(String string,int choice){
		 StringBuilder sb=new StringBuilder(string);
         for(int i=0;i<sb.length();i++){
        	 for(int j=i+1;j<sb.length();j++){
        		 if(sb.charAt(i)==sb.charAt(j)){
        			 sb.delete(i,i+1);
        			 break;
        		 }
        	 }
			}
         result=new String(sb);
		return result;
	}
	
	public String changeOdd(String string,int choice){
		 StringBuilder sb=new StringBuilder(string);
			for(int i=0;i<sb.length();i++){
				
				if(i%2!=0){
				char c = sb.charAt(i);
				 sb.setCharAt(i, Character.toUpperCase(c));
				}
			}
			result=new String(sb);
		return result;
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		User user=new User();
		System.out.println("enter the string");
		String string=sc.nextLine();
		System.out.println("1. Add the string to itself"+"\n"
		+"2. Replace odd positions with #"+"\n"
		+"3. Remove duplicate characters in the string"+"\n"
		+"4. Change odd characters to upper case");
		System.out.println("Please Enter your choice of action");
		int choice=sc.nextInt();
		switch(choice){
		case 1: user.addString(string,choice);
		break;
		case 2: user.replaceOdd(string,choice);
		break;
		case 3: user.removeDuplicate(string,choice);
		break;
		case 4: user.changeOdd(string,choice);
		break;
		default:
			System.out.println("Invalid choice.Please check the options");
		}
System.out.println(user.result);

sc.close();
	}

	

}
