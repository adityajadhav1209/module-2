package Lab3;

import java.util.Scanner;

public class StringCheck {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int c=0;
	System.out.println("enter the string");
	String string=sc.nextLine();
	for(int i=0;i<string.length()-1;i++){
	int asc1=(int)string.charAt(i);
	int asc2=(int)string.charAt(i+1);
	sc.close();
	if(asc1>asc2){
		c++;
		break;
	}
	}
	if(c==0){
		System.out.println("String is Positive");
	}
	else{
		System.out.println("String is negative");
	}
	}
	

	}


