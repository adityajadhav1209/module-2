package Lab10_1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Persons10b {
	
	
	
	
public static void loadProperties()
{
	Properties prop = new Properties();
	InputStream input= null;
	try {
		input = new FileInputStream("oracle1.properties");
		prop.load(input);
		System.out.println(prop.getProperty("Name"));
		   System.out.println(prop.getProperty("Age"));
			System.out.println(prop.getProperty("Designation"));
			
	} catch (FileNotFoundException e) {
	
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally
	{if(input!=null){
		try {
			input.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	}
	


}
	public static void main(String[] args) {
		loadProperties();

	}

}
