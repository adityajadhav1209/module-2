package Lab10_1;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;

public class Persons {
	
	
	
	
	
	public static void writeProperties()
	{
		
		Properties prop = new Properties();
		OutputStream output = null;
		try {
			output = new FileOutputStream("oracle1.properties");
		 
		prop.setProperty("Name", "Aditya Jadhav");
		prop.setProperty("Age", "22");
		prop.setProperty("Designation", "failed software developer");
		prop.store(output,null);
		prop.list(System.out);
		}
catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println(e);
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		
   writeProperties();
	}

}
