
public class Rectangle extends Shape{

	
	 private int length;
	 private int breadth;
	 
	 
	public Rectangle() {
		super();
		
	}
	


	public Rectangle(int length, int breadth) {
		super();
		this.length = 3;
		this.breadth = 4;
	}



	@Override
	public void draw() {
		System.out.println("rectangle is drawn");
		
	}

}
